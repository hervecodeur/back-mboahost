<?php
   $lang [ 'welcome_message' ] =  'Welcome to CodexWorld' ;
;?>